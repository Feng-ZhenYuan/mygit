package org.lanqiao.algo.elementary._09_Linear._01_oop;

public class Teacher {
  private String name;
  private int ability;

  private Student[] students;


}
