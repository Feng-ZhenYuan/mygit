
/**
 * 数论相关
 * @author zhengwei lastmodified 2017年4月8日
 *
 */
package org.lanqiao.algo.elementary.digit;