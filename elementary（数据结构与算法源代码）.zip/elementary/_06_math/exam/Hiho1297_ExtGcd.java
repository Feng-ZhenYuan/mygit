package org.lanqiao.algo.elementary._06_math.exam;

public class Hiho1297_ExtGcd {
}
