package org.lanqiao.algo.elementary._01xor;

public class _00位运算 {
  public static void main(String[] args) {
    System.out.println((1 << 35));
    System.out.println((1 << 3));
  }
}
