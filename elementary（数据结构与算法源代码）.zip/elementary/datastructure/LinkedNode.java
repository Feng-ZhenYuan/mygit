package org.lanqiao.algo.elementary.datastructure;

/**
 * 简单单向链表的节点
 */
public class LinkedNode {
  public int value;
  public LinkedNode next;

  public LinkedNode(int value) {
    this.value = value;
  }
}

